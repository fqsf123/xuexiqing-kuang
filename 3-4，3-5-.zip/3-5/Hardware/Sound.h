#ifndef __Sound_H
#define __Sound_H

void Sound_Init(void);
void Sound_ON(void);
void Sound_OFF(void);
void Sound_Turn(void);


#endif
