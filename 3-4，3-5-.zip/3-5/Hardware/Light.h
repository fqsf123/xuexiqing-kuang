#ifndef __Light_H
#define __Light_H
void Light_Init(void);
uint8_t Light_GetNum(void);

#endif
