#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "Sound.h"
#include "Light.h"

int main(void)
{
	Sound_Init();//初始化蜂鸣器
	Light_Init();//初始化光敏传感器
	
	while(1)
	{
		if(Light_GetNum() ==1)
		{
			Sound_ON();
		}else{
			Sound_OFF();
		}
	}
}
