#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "LED.h"
#include "Key.h"

uint8_t KeyNum;

int main(void)
{
	LED_Init();//初始化LED
	Key_Init();//初始化按钮
	
	while(1)
	{
		KeyNum =Key_GetNum();//读取数值
		if(KeyNum==1)
		{	
			LED1_Turn();
		}
		if(KeyNum==2)
		{	
			LED2_Turn();
		}
	}	
}
