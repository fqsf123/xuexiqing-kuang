#include "stm32f10x.h"                  // Device header
#include "Delay.h"

int main(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//开启时钟
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP ;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);//初始化端口
	
	while(1)
	{
		GPIO_WriteBit(GPIOA, GPIO_Pin_0,Bit_RESET);//将PA0端口配置为低电平
		Delay_ms(500);//设置延时500ms
		GPIO_WriteBit(GPIOA, GPIO_Pin_0,Bit_SET);//将PA0端口配置为高电平
		Delay_ms(500);//设置延时500ms
	}	
}
